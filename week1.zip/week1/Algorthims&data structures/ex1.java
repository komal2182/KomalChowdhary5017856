
import java.util.*;

class Data {
    public long productId;
    static HashMap<Long, Integer> hm = new HashMap<>();
    static HashMap<Long, String> productName = new HashMap<>();
    static HashMap<Long, Double> price = new HashMap<>();
}

class Update {
    public void update() {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter id and quantity to update:");
        long id = sc.nextLong();
        int q = sc.nextInt();
        if (!Data.hm.containsKey(id)) {
            Data.hm.put(id, q);
        } else {
            Data.hm.put(id, q);
        }
    }
}

class Add {
    public void input() {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter id, name, quantity, price:");
        long id = sc.nextLong();
        String s = sc.next();
        int q = sc.nextInt();
        double p = sc.nextDouble();
        Data.hm.put(id, q);
        Data.productName.put(id, s);
        Data.price.put(id, p);
    }
}

class Delete {
    public void remove() {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter id to remove:");
        long id = sc.nextLong();
        if (!Data.hm.containsKey(id)) {
            System.out.println("No such item found");
        } else {
            Data.hm.remove(id);
            Data.productName.remove(id);
            Data.price.remove(id);
        }
    }
}

public class ex1 {
    public static void main(String[] args) {
        Add addObj = new Add();
        Update updateObj = new Update();
        Delete deleteObj = new Delete();

        Scanner sc = new Scanner(System.in);
        while (true) {
            System.out.println("Choose an option: 1) Add 2) Update 3) Delete 4) Exit");
            int choice = sc.nextInt();
            switch (choice) {
                case 1:
                    addObj.input();
                    break;
                case 2:
                    updateObj.update();
                    break;
                case 3:
                    deleteObj.remove();
                    break;
                case 4:
                    System.exit(0);
                    break;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }
    }
}

/*import java.util.*;
class data{
    public long productId;
    HashMap <Long,Integer>hm=new HashMap<>();
    HashMap <Long,String> ProductName=new HashMap<>();
    HashMap <Long,Double> price=new HashMap<>();
}
class update extends data{


   public void update ()
    {
        Scanner sc=new Scanner (System.in);
        System.out.println("enetr id and quatity to update");
        long id=sc.nextLong();
        int q=sc.nextInt();
        if(data.hm.containsKey(id)==false){
            System.out.println("no such item found");
            
        }
        else
        {
          
            data.hm.put(id,q);
        }
        
    }
    class add
    {
public void input()
{
    Scanner sc=new Scanner (System.in);
    System.out.println("enetr id, ,name,quatity,price");
        long id=sc.nextLong();
        String  s=sc.next();
        int q=sc.nextInt();
       Double p=sc.nextDouble();
        hm.put(id,q);
            ProductName.put(id,s);
            price.put(id,p);
}

    }
    class Delete
    {
        public void remove()
        {
            Scanner sc=new Scanner (System.in);
            System.out.println("enetr id to remove");
            long id=sc.nextLong();
        if(hm.containsKey(id)==false){
            System.out.println("no such item found");
            
        }
        else
        {
           hm.remove(id);
           ProductName.remove(id);
           price.remove(id);
        }
        }

    }
    class main
    {
        public static void main(String[] args) {
            add addObj = new add();
        update updateObj = new update();
        Delete deleteObj = new Delete();

        Scanner sc = new Scanner(System.in);
        while (true) {
            System.out.println("Choose an option: 1) Add 2) Update 3) Delete 4) Exit");
            int choice = sc.nextInt();
            switch (choice) {
                case 1:
                    addObj.input();
                    break;
                case 2:
                    updateObj.update();
                    break;
                case 3:
                    deleteObj.remove();
                    break;
                case 4:
                    System.exit(0);
                    break;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }
        }
    }
}
*/