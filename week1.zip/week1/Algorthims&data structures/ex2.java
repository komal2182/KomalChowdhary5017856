//productId, productName, and category.
import java.util.*;

class ecomerece
{
    static Scanner sc=new Scanner(System.in);
    public static void main(String[] args)
    {
        String res;
        product objdata=new product();
        objdata.input();
        System.out.println("Enter target");
        int target=sc.nextInt();
        Arrays.sort(product.productId);
        linear objlinear=new linear();
        res=objlinear.search(target, product.productId);
        System.out.println("linear search result"+res);
        binnary objbinnary=new binnary();
        res= objbinnary.bsearch(target,0, product.productId.length, product.productId);
                System.out.println("binary search result:"+res);

    }
}
class linear 
{
    
    String search(int target,int productId[])
    {
        for(int i=0;i<productId.length;i++)
        if(productId[i]==target)
        return("found");
        return("not found");
    }
}
class binnary
{
    String bsearch(int target,int beg,int end,int productId[])
    {
        if (beg <= end) {
            int mid = beg + (end - beg) / 2;
            if (productId[mid] == target)
                return "Found";
            else if (productId[mid] < target)
                return bsearch(target, mid + 1, end, productId);
            else if(productId[mid] > target)
                return bsearch(target, beg, mid - 1, productId);
        }
        return "Not found";
    }
}
class product
{
    static int productId[]=new int[10];
    String productName[]=new String[10] ;
    String category[]=new String[10];
    int n=10;
    Scanner sc=new Scanner(System.in);
    public void input()
    {
        System.out.println("enter 10 products id,name ,catergory");
        for(int i=0;i<n;i++)
        {productId[i]=sc.nextInt();
        productName[i]=sc.next();
        category[i]=sc.next();}
    }
}
