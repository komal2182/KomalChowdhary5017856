//bookId, title, and author
import java.util.*;

class Books
{
    static Scanner sc = new Scanner(System.in);
    public static void main(String[] args)
    {
        String res;
        Book objdata = new Book();
        objdata.input();
        System.out.println("Enter target book ID:");
        int target = sc.nextInt();
       // Arrays.sort(Book.bookId);
        LinearSearch objlinear = new LinearSearch();
        res = objlinear.search(target, Book.bookId);
        System.out.println("Linear search result: " + res);
        BinarySearch objbinary = new BinarySearch();
        res = objbinary.bsearch(target, 0, Book.bookId.length - 1, Book.bookId);
        System.out.println("Binary search result: " + res);
    }
}

class LinearSearch 
{
    String search(int target, int bookId[])
    {
        for (int i = 0; i < bookId.length; i++)
            if (bookId[i] == target)
                return "Found";
        return "Not found";
    }
}

class BinarySearch
{
    String bsearch(int target, int beg, int end, int bookId[])
    {
        if (beg <= end) {
            int mid = beg + (end - beg) / 2;
            if (bookId[mid] == target)
                return "Found";
            else if (bookId[mid] < target)
                return bsearch(target, mid + 1, end, bookId);
            else if (bookId[mid] > target)
                return bsearch(target, beg, mid - 1, bookId);
        }
        return "Not found";
    }
}

class Book
{
    static int bookId[] = new int[10];
    String title[] = new String[10];
    String author[] = new String[10];
    int n = 10;
    Scanner sc = new Scanner(System.in);
    public void input()
    {
        System.out.println("Enter 10 books' ID, title, and author:");
        for (int i = 0; i < n; i++) {
            bookId[i] = sc.nextInt();
            sc.nextLine(); 
            title[i] = sc.nextLine();
            author[i] = sc.nextLine();
        }
    }
}
