import java.util.*;

class Order {
    static int[] orderId = new int[10];
    String[] customerName = new String[10];
    double[] totalPrice = new double[10];
    int n = 10;
    Scanner sc = new Scanner(System.in);

    public void input() {
        System.out.println("Enter 10 orders with ID, customer name, and total price:");
        for (int i = 0; i < n; i++) {
            System.out.print("Order ID: ");
            orderId[i] = sc.nextInt();
            System.out.print("Customer Name: ");
            customerName[i] = sc.next();
            System.out.print("Total Price: ");
            totalPrice[i] = sc.nextDouble();
        }
    }

    public void display() {
        System.out.println("Order Details:");
        for (int i = 0; i < n; i++) {
            System.out.printf("Order ID: %d, Customer Name: %s, Total Price: %.2f%n", 
                              orderId[i], customerName[i], totalPrice[i]);
        }
    }

    
class QuickSort {
    public void quickSort(double[] arr, int low, int high) {
        if (low < high) {
            int pi = partition(arr, low, high);
            quickSort(arr, low, pi - 1);
            quickSort(arr, pi + 1, high);
        }
    }

    int partition(double[] arr, int low, int high) {
        double pivot = arr[high];
        int i = (low - 1);
        for (int j = low; j < high; j++) {
            if (arr[j] < pivot) {
                i++;
                double temp = arr[i];
                arr[i] = arr[j];
                arr[j] = temp;
            }
        }
        double temp = arr[i + 1];
        arr[i + 1] = arr[high];
        arr[high] = temp;
        return i + 1;
    }
}

class MergeSort {
    public void mergeSort(double[] arr, int left, int right) {
        if (left < right) {
            int mid = (left + right) / 2;
            mergeSort(arr, left, mid);
            mergeSort(arr, mid + 1, right);
            merge(arr, left, mid, right);
        }
    }

   void merge(double[] arr, int left, int mid, int right) {
        int n1 = mid - left + 1;
        int n2 = right - mid;
        double[] L = new double[n1];
        double[] R = new double[n2];
        System.arraycopy(arr, left, L, 0, n1);
        System.arraycopy(arr, mid + 1, R, 0, n2);
        int i = 0, j = 0;
        int k = left;
        while (i < n1 && j < n2) {
            if (L[i] <= R[j]) {
                arr[k] = L[i];
                i++;
            } else {
                arr[k] = R[j];
                j++;
            }
            k++;
        }
        while (i < n1) {
            arr[k] = L[i];
            i++;
            k++;
        }
        while (j < n2) {
            arr[k] = R[j];
            j++;
            k++;
        }
    }
}

public class Main {
    public static void main(String[] args) {
        Order orderManager = new Order();
        orderManager.input();
        orderManager.display();

        QuickSort quickSort = new QuickSort();
        quickSort.quickSort(orderManager.totalPrice, 0, orderManager.totalPrice.length - 1);
        System.out.println("Total Prices after Quick Sort:");
        System.out.println(Arrays.toString(orderManager.totalPrice));

        MergeSort mergeSort = new MergeSort();
        mergeSort.mergeSort(orderManager.totalPrice, 0, orderManager.totalPrice.length - 1);
        System.out.println("Total Prices after Merge Sort:");
        System.out.println(Arrays.toString(orderManager.totalPrice));
    }
}
