import java.util.*;
class Employee
{
    
    int employeeId;
    String name;
    String position;
    double salary;

    public Employee(int employeeId, String name, String position, double salary)
     {
        this.employeeId = employeeId;
        this.name = name;
        this.position = position;
        this.salary = salary;
    }
}
class Management
{
     Employee[] employees;
     int count=0;
    public  Management (int capacity) 
    {
        employees = new Employee[capacity];
        count = 0;
    }
    public void add(Employee employee)
    {
        employees[count++]=employee;

    }
    public String search(int employeeId) {
        for (int i = 0; i < count; i++) {
            if (employees[i].employeeId == employeeId) {
                return("Added") ;
            }
        }
        return("space full"); // Employee not found
    }
    public void delete(int employeeId) {
        
        for (int i = 0; i < count; i++) {
            if (employees[i].employeeId == employeeId) {
                employees[i] = employees[--count]; // Replace with last element
                employees[count] = null; // Remove last element
                return;
            }
        }
        System.out.println("Employee not found.");
        }
        public void traverse() {
            for (int i = 0; i < count; i++) {
                System.out.println(employees[i]);
            }
        }
        public static void main(String[] args) {
            Management ems = new Management(5);
    
            ems.add(new Employee(1, "Komal", "Developer", 90000));
            ems.add(new Employee(2, "Ankita", "Manager", 80000));
            ems.add(new Employee(3, "Keshav", "HR", 90000));
            ems.add(new Employee(4, "Kavita", "Developer", 90000));
            ems.add(new Employee(5, "Chirag", "Analyst", 60000));
    
            System.out.println("All Employees:");
            ems.traverse();
            System.out.println("Search for Employee ID 2:");
            System.out.println(ems.search(2));
            System.out.println("Deleting Employee ID 2:");
            ems.delete(2);
            System.out.println("All Employees after deletion:");
            ems.traverse();
        }
    }
        
        
       