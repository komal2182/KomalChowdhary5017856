

public class WebApp implements Observer {
    private String webAppName;

    public WebApp(String webAppName) {
        this.webAppName = webAppName;
    }

    @Override
    public void update(double stockPrice) {
        System.out.println(webAppName + " received stock price update: " + stockPrice);
    }
}
