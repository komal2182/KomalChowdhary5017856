package com.library.service;

public class BookService {
    public void displayService() {
    }
    // Service logic here
}
