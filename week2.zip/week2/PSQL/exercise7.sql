CREATE SCHEMA customer_management;

CREATE OR REPLACE FUNCTION customer_management.get_customer_balance(p_CustomerID INT) RETURNS NUMERIC AS $$
DECLARE
    v_Balance NUMERIC;
BEGIN
    SELECT Balance INTO v_Balance FROM Customers WHERE CustomerID = p_CustomerID;
    RETURN v_Balance;
END;
$$ LANGUAGE plpgsql;

CREATE OR REPLACE PROCEDURE customer_management.add_new_customer(p_CustomerID INT, p_Name VARCHAR, p_DOB DATE, p_Balance NUMERIC) AS $$
BEGIN
    INSERT INTO Customers (CustomerID, Name, DOB, Balance, LastModified)
    VALUES (p_CustomerID, p_Name, p_DOB, p_Balance, CURRENT_DATE);
END;
$$ LANGUAGE plpgsql;

CREATE OR REPLACE PROCEDURE customer_management.update_customer_details(p_CustomerID INT, p_Name VARCHAR, p_DOB DATE, p_Balance NUMERIC) AS $$
BEGIN
    UPDATE Customers
    SET Name = p_Name, DOB = p_DOB, Balance = p_Balance, LastModified = CURRENT_DATE
    WHERE CustomerID = p_CustomerID;
END;
$$ LANGUAGE plpgsql;

CREATE SCHEMA employee_management;

CREATE OR REPLACE FUNCTION employee_management.calculate_annual_salary(p_EmployeeID INT) RETURNS NUMERIC AS $$
DECLARE
    v_Salary NUMERIC;
BEGIN
    SELECT Salary INTO v_Salary FROM Employees WHERE EmployeeID = p_EmployeeID;
    RETURN v_Salary * 12;
END;
$$ LANGUAGE plpgsql;

CREATE OR REPLACE PROCEDURE employee_management.hire_new_employee(p_EmployeeID INT, p_Name VARCHAR, p_Position VARCHAR, p_Salary NUMERIC, p_Department VARCHAR, p_HireDate DATE) AS $$
BEGIN
    INSERT INTO Employees (EmployeeID, Name, Position, Salary, Department, HireDate)
    VALUES (p_EmployeeID, p_Name, p_Position, p_Salary, p_Department, p_HireDate);
END;
$$ LANGUAGE plpgsql;

CREATE OR REPLACE PROCEDURE employee_management.update_employee_details(p_EmployeeID INT, p_Name VARCHAR, p_Position VARCHAR, p_Salary NUMERIC, p_Department VARCHAR) AS $$
BEGIN
    UPDATE Employees
    SET Name = p_Name, Position = p_Position, Salary = p_Salary, Department = p_Department
    WHERE EmployeeID = p_EmployeeID;
END;
$$ LANGUAGE plpgsql;

CREATE SCHEMA account_operations;

CREATE OR REPLACE PROCEDURE account_operations.open_new_account(p_AccountID INT, p_CustomerID INT, p_AccountType VARCHAR, p_Balance NUMERIC) AS $$
BEGIN
    INSERT INTO Accounts (AccountID, CustomerID, AccountType, Balance, LastModified)
    VALUES (p_AccountID, p_CustomerID, p_AccountType, p_Balance, CURRENT_DATE);
END;
$$ LANGUAGE plpgsql;

CREATE OR REPLACE PROCEDURE account_operations.close_account(p_AccountID INT) AS $$
BEGIN
    DELETE FROM Accounts WHERE AccountID = p_AccountID;
END;
$$ LANGUAGE plpgsql;

CREATE OR REPLACE FUNCTION account_operations.get_total_balance(p_CustomerID INT) RETURNS NUMERIC AS $$
DECLARE
    v_TotalBalance NUMERIC;
BEGIN
    SELECT COALESCE(SUM(Balance), 0) INTO v_TotalBalance FROM Accounts WHERE CustomerID = p_CustomerID;
    RETURN v_TotalBalance;
END;
$$ LANGUAGE plpgsql;
