CREATE OR REPLACE FUNCTION ProcessMonthlyInterest() RETURNS VOID AS $$
DECLARE
    savings_rec RECORD;
BEGIN
    FOR savings_rec IN (SELECT AccountID, Balance FROM Accounts WHERE AccountType = 'Savings' FOR UPDATE) LOOP
        UPDATE Accounts SET Balance = savings_rec.Balance + (savings_rec.Balance * 0.01) WHERE AccountID = savings_rec.AccountID;
    END LOOP;
    COMMIT;
END;
$$ LANGUAGE plpgsql;
CREATE OR REPLACE FUNCTION UpdateEmployeeBonus(p_Department VARCHAR, p_BonusPercentage NUMERIC) RETURNS VOID AS $$
BEGIN
    UPDATE Employees
    SET Salary = Salary + (Salary * p_BonusPercentage / 100)
    WHERE Department = p_Department;
    
    COMMIT;
END;
$$ LANGUAGE plpgsql;
CREATE OR REPLACE FUNCTION TransferFunds(p_FromAccountID INT, p_ToAccountID INT, p_Amount NUMERIC) RETURNS VOID AS $$
DECLARE
    v_FromBalance NUMERIC;
BEGIN
    SELECT Balance INTO v_FromBalance FROM Accounts WHERE AccountID = p_FromAccountID FOR UPDATE;

    IF v_FromBalance < p_Amount THEN
        RAISE EXCEPTION 'Insufficient funds in the source account.';
    END IF;

    UPDATE Accounts SET Balance = Balance - p_Amount WHERE AccountID = p_FromAccountID;
    UPDATE Accounts SET Balance = Balance + p_Amount WHERE AccountID = p_ToAccountID;

    COMMIT;
EXCEPTION
    WHEN OTHERS THEN
        ROLLBACK;
        RAISE NOTICE 'Error: %', SQLERRM;
END;
$$ LANGUAGE plpgsql;
