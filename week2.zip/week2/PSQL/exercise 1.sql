
-- create
CREATE TABLE EMPLOYEE (
  empId INTEGER PRIMARY KEY,
  name TEXT NOT NULL,
  dept TEXT NOT NULL
);

-- insert
INSERT INTO EMPLOYEE VALUES (0001, 'Clark', 'Sales');
INSERT INTO EMPLOYEE VALUES (0002, 'Dave', 'Accounting');
INSERT INTO EMPLOYEE VALUES (0003, 'Ava', 'Sales');

-- fetch 
SELECT * FROM EMPLOYEE WHERE dept = 'Sales';

DO $$
DECLARE
    customer_rec RECORD;
    v_Age INT;
BEGIN
    FOR customer_rec IN (SELECT CustomerID, DOB FROM Customers) LOOP
        -- Calculate Age
        v_Age := DATE_PART('year', AGE(customer_rec.DOB));
        
        IF v_Age > 60 THEN
            UPDATE Loans
            SET InterestRate = InterestRate - 1
            WHERE CustomerID = customer_rec.CustomerID;
        END IF;
    END LOOP;
END $$;
DO $$
DECLARE
    customer_rec RECORD;
BEGIN
    FOR customer_rec IN (SELECT CustomerID, Balance FROM Customers) LOOP
        IF customer_rec.Balance > 10000 THEN
            UPDATE Customers
            SET IsVIP = TRUE
            WHERE CustomerID = customer_rec.CustomerID;
        END IF;
    END LOOP;
END $$;
DO $$
DECLARE
    loan_rec RECORD;
BEGIN
    FOR loan_rec IN (SELECT CustomerID, LoanID, EndDate FROM Loans WHERE EndDate <= CURRENT_DATE + INTERVAL '30 days') LOOP
        RAISE NOTICE 'Reminder: Loan ID % for Customer ID % is due on %', loan_rec.LoanID, loan_rec.CustomerID, loan_rec.EndDate;
    END LOOP;
END $$;

