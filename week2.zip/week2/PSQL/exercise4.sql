CREATE OR REPLACE FUNCTION CalculateAge(p_DOB DATE) RETURNS INT AS $$
BEGIN
    RETURN DATE_PART('year', AGE(p_DOB));
END;
$$ LANGUAGE plpgsql;

CREATE OR REPLACE FUNCTION CalculateMonthlyInstallment(p_LoanAmount NUMERIC, p_InterestRate NUMERIC, p_LoanDurationYears INT) RETURNS NUMERIC AS $$
DECLARE
    v_MonthlyInstallment NUMERIC;
    v_MonthlyRate NUMERIC;
    v_NumberOfPayments INT;
BEGIN
    v_MonthlyRate := p_InterestRate / 12 / 100;
    v_NumberOfPayments := p_LoanDurationYears * 12;
    v_MonthlyInstallment := p_LoanAmount * v_MonthlyRate / (1 - POWER(1 + v_MonthlyRate, -v_NumberOfPayments));
    RETURN v_MonthlyInstallment;
END;
$$ LANGUAGE plpgsql;

CREATE OR REPLACE FUNCTION HasSufficientBalance(p_AccountID INT, p_Amount NUMERIC) RETURNS BOOLEAN AS $$
DECLARE
    v_Balance NUMERIC;
BEGIN
    SELECT Balance INTO v_Balance FROM Accounts WHERE AccountID = p_AccountID;
    RETURN v_Balance >= p_Amount;
END;
$$ LANGUAGE plpgsql;
