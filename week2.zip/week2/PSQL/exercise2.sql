CREATE OR REPLACE FUNCTION SafeTransferFunds(p_FromAccountID INT, p_ToAccountID INT, p_Amount NUMERIC) RETURNS VOID AS $$
DECLARE
    v_FromBalance NUMERIC;
    v_ToBalance NUMERIC;
BEGIN
    SELECT Balance INTO v_FromBalance FROM Accounts WHERE AccountID = p_FromAccountID FOR UPDATE;
    SELECT Balance INTO v_ToBalance FROM Accounts WHERE AccountID = p_ToAccountID FOR UPDATE;

    IF v_FromBalance < p_Amount THEN
        RAISE EXCEPTION 'Insufficient funds in the source account.';
    END IF;

    UPDATE Accounts SET Balance = v_FromBalance - p_Amount WHERE AccountID = p_FromAccountID;
    UPDATE Accounts SET Balance = v_ToBalance + p_Amount WHERE AccountID = p_ToAccountID;

    COMMIT;
EXCEPTION
    WHEN OTHERS THEN
        ROLLBACK;
        RAISE NOTICE 'Error: %', SQLERRM;
END;
$$ LANGUAGE plpgsql;

CREATE OR REPLACE FUNCTION UpdateSalary(p_EmployeeID INT, p_Percentage NUMERIC) RETURNS VOID AS $$
DECLARE
    v_Salary NUMERIC;
BEGIN
    BEGIN
        SELECT Salary INTO v_Salary FROM Employees WHERE EmployeeID = p_EmployeeID FOR UPDATE;
        
        UPDATE Employees SET Salary = Salary + (Salary * p_Percentage / 100) WHERE EmployeeID = p_EmployeeID;
        
        COMMIT;
    EXCEPTION
        WHEN NO_DATA_FOUND THEN
            RAISE NOTICE 'Error: Employee ID % does not exist.', p_EmployeeID;
    END;
END;
$$ LANGUAGE plpgsql;

CREATE OR REPLACE FUNCTION AddNewCustomer(p_CustomerID INT, p_Name VARCHAR, p_DOB DATE, p_Balance NUMERIC) RETURNS VOID AS $$
BEGIN
    BEGIN
        INSERT INTO Customers (CustomerID, Name, DOB, Balance, LastModified)
        VALUES (p_CustomerID, p_Name, p_DOB, p_Balance, CURRENT_DATE);
        
        COMMIT;
    EXCEPTION
        WHEN unique_violation THEN
            RAISE NOTICE 'Error: Customer ID % already exists.', p_CustomerID;
    END;
END;
$$ LANGUAGE plpgsql;
