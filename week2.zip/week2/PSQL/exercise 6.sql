DO $$
DECLARE
    transaction_rec RECORD;
BEGIN
    FOR transaction_rec IN (SELECT * FROM Transactions WHERE TransactionDate >= CURRENT_DATE - INTERVAL '1 month') LOOP
        RAISE NOTICE 'Monthly Statement for Customer %: %', transaction_rec.CustomerID, transaction_rec.Amount;
    END LOOP;
END $$;

DO $$
DECLARE
    transaction_volume NUMERIC;
BEGIN
    SELECT SUM(Amount) INTO transaction_volume FROM Transactions WHERE TransactionDate = CURRENT_DATE;

    IF transaction_volume > 1000000 THEN
        RAISE NOTICE 'Alert: High transaction volume today: %', transaction_volume;
    END IF;
END $$;

DO $$
DECLARE
    customer_rec RECORD;
BEGIN
    FOR customer_rec IN (SELECT * FROM BulkCustomers) LOOP
        IF customer_rec.Balance < 0 THEN
            RAISE NOTICE 'Error: Negative balance for Customer ID %', customer_rec.CustomerID;
        ELSIF customer_rec.DOB > CURRENT_DATE THEN
            RAISE NOTICE 'Error: Future date of birth for Customer ID %', customer_rec.CustomerID;
        END IF;
    END LOOP;
END $$;
