CREATE OR REPLACE FUNCTION UpdateCustomerLastModified() RETURNS TRIGGER AS $$
BEGIN
    NEW.LastModified := CURRENT_DATE;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER UpdateCustomerLastModified
BEFORE UPDATE ON Customers
FOR EACH ROW
EXECUTE FUNCTION UpdateCustomerLastModified();

CREATE OR REPLACE FUNCTION LogTransaction() RETURNS TRIGGER AS $$
BEGIN
    INSERT INTO AuditLog (TransactionID, AccountID, TransactionDate, Amount, TransactionType)
    VALUES (NEW.TransactionID, NEW.AccountID, NEW.TransactionDate, NEW.Amount, NEW.TransactionType);
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER LogTransaction
AFTER INSERT ON Transactions
FOR EACH ROW
EXECUTE FUNCTION LogTransaction();

CREATE OR REPLACE FUNCTION CheckTransactionRules() RETURNS TRIGGER AS $$
BEGIN
    IF NEW.TransactionType = 'Withdrawal' AND NEW.Amount > (SELECT Balance FROM Accounts WHERE AccountID = NEW.AccountID) THEN
        RAISE EXCEPTION 'Insufficient balance.';
    ELSIF NEW.TransactionType = 'Deposit' AND NEW.Amount <= 0 THEN
        RAISE EXCEPTION 'Deposit amount must be positive.';
    END IF;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER CheckTransactionRules
BEFORE INSERT ON Transactions
FOR EACH ROW
EXECUTE FUNCTION CheckTransactionRules();
