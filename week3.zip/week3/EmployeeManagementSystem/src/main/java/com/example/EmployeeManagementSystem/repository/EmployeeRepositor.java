package com.example.EmployeeManagementSystem.repository;

import com.example.EmployeeManagementSystem.entity.Employee;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;

public interface EmployeeRepository extends JpaRepository<Employee, Long> {

    // Derived Query Methods
    List<Employee> findByDepartmentId(Long departmentId);

    List<Employee> findByNameContaining(String name);

    List<Employee> findByEmailEndingWith(String domain);

    // Custom Query using @Query
    @Query("SELECT e FROM Employee e WHERE e.email LIKE %:domain")
    List<Employee> findEmployeesByEmailDomain(@Param("domain") String domain);
}
package com.example.EmployeeManagementSystem.repository;

import com.example.EmployeeManagementSystem.entity.Employee;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;

public interface EmployeeRepository extends JpaRepository<Employee, Long> {

    // Other methods...

    // Pagination
    Page<Employee> findAll(Pageable pageable);
}
package com.example.EmployeeManagementSystem.repository;

import com.example.EmployeeManagementSystem.entity.Employee;
import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface EmployeeRepository extends JpaRepository<Employee, Long> {

    // Other methods...

    // Sorting by a specific field
    List<Employee> findAll(Sort sort);

    // Example: Find by department ID with sorting
    List<Employee> findByDepartmentId(Long departmentId, Sort sort);
}
