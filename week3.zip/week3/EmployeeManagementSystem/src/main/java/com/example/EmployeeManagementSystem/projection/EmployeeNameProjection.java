package com.example.EmployeeManagementSystem.repository;

import com.example.EmployeeManagementSystem.entity.Employee;
import com.example.EmployeeManagementSystem.projection.EmployeeNameProjection;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface EmployeeRepository extends JpaRepository<Employee, Long> {

    List<EmployeeNameProjection> findByDepartmentId(Long departmentId);
}
package com.example.EmployeeManagementSystem.projection;

public class EmployeeNameDTO {

    private String name;
    private String email;

    public EmployeeNameDTO(String name, String email) {
        this.name = name;
        this.email = email;
    }

    // Getters and Setters
}
package com.example.EmployeeManagementSystem.repository;

import com.example.EmployeeManagementSystem.entity.Employee;
import com.example.EmployeeManagementSystem.projection.EmployeeNameDTO;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;

public interface EmployeeRepository extends JpaRepository<Employee, Long> {

    @Query("SELECT new com.example.EmployeeManagementSystem.projection.EmployeeNameDTO(e.name, e.email) " +
            "FROM Employee e WHERE e.department.id = :departmentId")
    List<EmployeeNameDTO> findEmployeeNamesByDepartmentId(@Param("departmentId") Long departmentId);
}

