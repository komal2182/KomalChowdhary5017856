package org.example.bookstoreapi.controller;

import org.example.bookstoreapi.entity.Customer;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;

@RestController
@RequestMapping("/customers")
public class CustomerController {

    private List<Customer> customers = new ArrayList<>();

    // POST /customers - Create a new customer using JSON request body
    @PostMapping
    public Customer createCustomer(@RequestBody Customer customer) {
        customer.setId((long) (customers.size() + 1)); // Assign a new ID
        customers.add(customer);
        return customer;

    }

    @PostMapping("/form")
    public Customer registerCustomerUsingFormData(@RequestParam String name,
                                                  @RequestParam String email,
                                                  @RequestParam String password) {
        Customer customer = new Customer((long) (customers.size() + 1), name, email, password);
        customers.add(customer);
        return customer;
    }
}
