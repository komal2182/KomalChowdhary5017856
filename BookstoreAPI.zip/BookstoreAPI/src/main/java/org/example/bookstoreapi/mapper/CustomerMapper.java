package org.example.bookstoreapi.mapper;

import org.example.bookstoreapi.dto.CustomerDTO;
import org.example.bookstoreapi.entity.Customer;
import org.mapstruct.Mapper;

@Mapper(componentModel = "spring")
public interface CustomerMapper {
    CustomerDTO toDto(Customer customer);
    Customer toEntity(CustomerDTO customerDTO);
}
