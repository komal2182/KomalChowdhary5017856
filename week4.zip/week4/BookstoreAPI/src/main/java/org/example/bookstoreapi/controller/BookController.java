package org.example.bookstoreapi.controller;

import org.example.bookstoreapi.dto.BookDTO;
import org.example.bookstoreapi.entity.Book;
import org.example.bookstoreapi.mapper.BookMapper;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;

@RestController
@RequestMapping("/books")
class BookController {

    private final BookMapper bookMapper;
    private List<Book> books = new ArrayList<>();

    public BookController(BookMapper bookMapper) {
        this.bookMapper = bookMapper;
        books.add(new Book(1L, "The Great Gatsby", "F. Scott Fitzgerald", 10.99, "9780743273565"));
        books.add(new Book(2L, "1984", "George Orwell", 8.99, "9780451524935"));
    }

    @PostMapping
    public ResponseEntity<BookDTO> addBook(@RequestBody BookDTO bookDTO) {
        Book book = bookMapper.toEntity(bookDTO);
        book.setId((long) (books.size() + 1));
        books.add(book);
        return ResponseEntity.status(HttpStatus.CREATED).body(bookMapper.toDto(book));
    }

    @GetMapping("/{id}")
    public ResponseEntity<BookDTO> getBookById(@PathVariable Long id) {
        Book book = books.stream()
                .filter(b -> b.getId().equals(id))
                .findFirst()
                .orElse(null);

        if (book == null) {
            return ResponseEntity.notFound().build();
        }

        return ResponseEntity.ok(bookMapper.toDto(book));
    }
}
