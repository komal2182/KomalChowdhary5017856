package org.example.bookstoreapi.mapper;

import org.example.bookstoreapi.dto.BookDTO;
import org.example.bookstoreapi.entity.Book;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

@Mapper(componentModel = "spring")
public interface BookMapper {
    BookDTO toDto(Book book);
    Book toEntity(BookDTO bookDTO);
}
