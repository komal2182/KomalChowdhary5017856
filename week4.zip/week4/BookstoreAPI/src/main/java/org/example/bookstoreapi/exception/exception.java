package org.example.bookstoreapi.exception;
public class exception {

   public static class ResourceNotFoundException extends RuntimeException {
         public ResourceNotFoundException(String message) {
            super(message);
        }
    }


    class BadRequestException extends RuntimeException {
       BadRequestException(String message) {
            super(message);
        }
    }
}