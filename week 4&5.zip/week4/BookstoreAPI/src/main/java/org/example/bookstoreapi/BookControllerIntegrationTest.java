package org.example.bookstoreapi;

import org.example.bookstoreapi.entity.Book;
import org.example.bookstoreapi.repository.BookRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.jdbc.Sql;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@SpringBootTest
@Sql(scripts = "/test-schema.sql", executionPhase = Sql.ExecutionPhase.BEFORE_TEST_METHOD)
public class BookControllerIntegrationTest {


    private MockMvc mockMvc;


    private BookRepository bookRepository;

    @BeforeEach
    public void setUp() {
        // Initialize your test data or clear the database
        bookRepository.deleteAll();
    }

    @Test
    public void testCreateBook() throws Exception {
        String bookJson = "{\"id\":\"1\",\"title\":\"Effective Java\",\"author\":\"Joshua Bloch\",\"price\":45.00,\"isbn\":\"1234567890\"}";

        mockMvc.perform(post("/books")
                        .contentType("application/json")
                        .content(bookJson))
                .andExpect(status().isCreated())
                .andExpect(jsonPath("$.title").value("Effective Java"));
    }

    @Test
    public void testGetBookById() throws Exception {
        bookRepository.save(new Book("1", "Effective Java", "Joshua Bloch", 45.00, "1234567890"));

        mockMvc.perform(MockMvcRequestBuilders.get("/books/1"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.title").value("Effective Java"));
    }

    @Test
    public void testUpdateBook() throws Exception {
        bookRepository.save(new Book("1", "Effective Java", "Joshua Bloch", 45.00, "1234567890"));

        String updatedBookJson = "{\"title\":\"Effective Java Updated\",\"author\":\"Joshua Bloch\",\"price\":50.00,\"isbn\":\"1234567890\"}";

        mockMvc.perform(MockMvcRequestBuilders.put("/books/1")
                        .contentType("application/json")
                        .content(updatedBookJson))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.title").value("Effective Java Updated"));
    }

    @Test
    public void testDeleteBook() throws Exception {
        bookRepository.save(new Book("1", "Effective Java", "Joshua Bloch", 45.00, "1234567890"));

        mockMvc.perform(MockMvcRequestBuilders.delete("/books/1"))
                .andExpect(status().isNoContent());
    }
}
