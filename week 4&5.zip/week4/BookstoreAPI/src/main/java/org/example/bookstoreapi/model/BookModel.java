package org.example.bookstoreapi.model;

import org.example.bookstoreapi.controller.BookController;
import org.example.bookstoreapi.entity.Book;
import org.springframework.hateoas.RepresentationModel;
import org.springframework.hateoas.server.mvc.WebMvcLinkBuilder;

public class BookModel extends RepresentationModel<BookModel> {

    private Long id;
    private String title;
    private String author;
    private double price;
    private String isbn;

    // Constructor to map Book entity to BookModel
    public BookModel(Book book) {
        this.id = book.getId();
        this.title = book.getTitle();
        this.author = book.getAuthor();
        this.price = book.getPrice();
        this.isbn = book.getIsbn();

        // Adding self-link to the BookModel
        add(WebMvcLinkBuilder.linkTo(WebMvcLinkBuilder.methodOn(BookController.class).getBookById(id)).withSelfRel());
    }

    // Getters and Setters
}
