package org.example.bookstoreapi.config;

import io.micrometer.core.instrument.MeterRegistry;
import org.springframework.context.annotation.Configuration;

import javax.annotation.PostConstruct;

@Configuration
public class CustomMetricsConfig {

    private final MeterRegistry meterRegistry;

    public CustomMetricsConfig(MeterRegistry meterRegistry) {
        this.meterRegistry = meterRegistry;
    }

    @PostConstruct
    public void initCustomMetrics() {
        meterRegistry.counter("bookstore.books.added").increment(0);
        meterRegistry.gauge("bookstore.books.in-stock", 100);
    }
}
