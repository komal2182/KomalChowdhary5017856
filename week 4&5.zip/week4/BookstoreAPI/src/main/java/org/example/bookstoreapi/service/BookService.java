package org.example.bookstoreapi.service;

import org.example.bookstoreapi.entity.Book;
import org.example.bookstoreapi.repository.BookRepository;
import io.micrometer.core.instrument.MeterRegistry;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class BookService {

    private final BookRepository bookRepository;
    private final MeterRegistry meterRegistry;

    @Autowired
    public BookService(BookRepository bookRepository, MeterRegistry meterRegistry) {
        this.bookRepository = bookRepository;
        this.meterRegistry = meterRegistry;
    }

    public Book addBook(Book book) {
        meterRegistry.counter("bookstore.books.added").increment();
        return bookRepository.save(book);
    }

    public Object createBook(Book any) {
        return null;
    }

    public Object getBookById(String number) {
        return null;
    }

    public Object updateBook(String any, Book any1) {
        return null;
    }

    public List<Book> getAllBooks() {
        return List.of();
    }

    public void deleteBook(Long id) {
    }
}
